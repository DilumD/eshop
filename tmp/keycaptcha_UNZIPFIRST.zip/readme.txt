KeyCAPTCHA Installation:
1. Register on and log-in to our site (https://www.keycaptcha.com/accounts/reguser).
2. Add your site URL on "My Sites" page (note that you can add many sites to protect under the same account).
3. Choose Joomla from "CMS" dropdown.
4. Choose the version of your Joomla.
5. Choose "Installation Instructions" in the right menu "Free Account".
6. Follow KeyCAPTCHA installation instructions on the opened page.

KeyCAPTCHA Upgrade:
To upgrade KeyCAPTCHA plugin you have to uninstall the previous version.
